namespace robot_controller_api;

public class Map
{
    /// Implement <see cref="Map"> here following the task sheet requirements
}
